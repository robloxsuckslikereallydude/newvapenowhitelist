# the #1 vape mod for bedwars

**Socials**<br>
**[Discord](https://discord.gg/B5hKEKQ83a)**<br>
**[YouTube](https://www.youtube.com/@0prime)**<br>


## Loadstring

```lua
    loadstring(game:HttpGet("https://raw.githubusercontent.com/skiddinglua/NewVape/main/Initiate.lua", true))()
```


## People:

+ <b>0prime (skiddinglua) \[[Discord](https://discord.com/users/1095127276099752078)\]</b>
    + Owner
    + Makes 60% of the issues
    + **NOT A DEV**
+ <b>blankedvoid (SystemXVoid) \[[Discord](https://discord.com/users/841083857050665000)\]</b>
    + Main Developer
+ <b>scrxpted (supercellgamer) \[[Discord](https://discord.com/users/759071932276146216)\]</b>
    + Developer
    + Fixes 90% of the issues
+ <b>luckii (cdezxswzq) \[[Discord](https://discord.com/users/900857825788583956)\]</b>
    + :\)
+ <b>inumgaming (?) \[[Discord](https://discord.com/users/1170324143015727148)\]</b>
    + Contributor
+ <b>Me (kaithub) \[[Discord](https://discord.com/users/1128579930586877962)\]</b>
    + Contributor

## Features
+ Invisibility
    + Hides your character below the map (you are still visible if they look towards the void)
+ Teleport
    + Teleports you to Players, Beds, or your desired location
    + Modes: Telepearl, Redirect, Jade Hammer, Dao
+ KeepInventory
    + Attempts to move items to your enderchest when you have low health/lagback
+ AnticheatAbuse
    + Partially bypasses the anticheat
+ NoPing
    + Unbinds your ping keybinds
+ Privacy
    + Blocks some analytics
+ FpsBoostPlus
    + Gives a huge FPS boost!
+ Atmosphere
    + Changes how the game visually looks
+ HotbarMods
    + Makes the hotbar look more smooth and clean
+ HealthbarMods
    + Makes the healthbar look more crisp
+ Network
    + Fixed network ownership issues
+ Better Cache Refresh
    + Optimized the caching system to only redownload files that have been changed instead of redownloading everything after an update
+ Killaura
    + Made many changes to the internal aura to greatly improve hitreg
    + Added toggle to pause attack packets during ping spikes
    + Added serverside rotation toggles to make weapon exploits more convenient
    + Added over 70+ killaura animations
+ AutoKit
    + Added Hannah to AutoKit
    + Fixed GetTeammateThatNeedsMost function
+ Memory
    + Added MemoryManager
    + Fixed some memory leaks
+ Internal APIs
    + Added MessageHandler
    + Added Colorize
    + Added exceptionHandler
    + Added GuiHandler
    + Many more new functions
